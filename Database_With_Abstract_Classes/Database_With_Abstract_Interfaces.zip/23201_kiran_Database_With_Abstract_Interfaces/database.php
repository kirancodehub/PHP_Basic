<?php

require_once("database_settings.php");

interface database
{
    public function get_connection();
    public function query_execute($query);
    public function con_close();
}

class databaseConnect implements database
{
    protected $hostname;
    protected $username;
    protected $password;
    protected $database_name;

    public $connection;
    public $query;
    public $result;

    public function __construct($hostname,$username,$password,$database_name)
    {
        $this->hostname      = $hostname;
        $this->username      = $username;
        $this->password      = $password;
        $this->database_name = $database_name;
    }

    public function get_connection()
    {
        $this->connection = mysqli_connect(
            $this->hostname,
            $this->username,
            $this->password,
            $this->database_name
        );

        if(!$this->connection)
        {
            die("Connection Failed : ".mysqli_connect_error());
        }
    }

    public function query_execute($query)
    {
        $this->query = $query;
        $this->result = mysqli_query($this->connection,$this->query);

        return $this->result;
    }

    public function con_close()
    {
        mysqli_close($this->connection);
    }
}
?>