<?php

require_once("database.php");

$connect = new databaseConnect($hostname,$username,$password,$database_name);
$connect->get_connection();

if(isset($_POST['submit']))
{
    $name  = $_POST['name'];
    $email = $_POST['email'];

    $query = "INSERT INTO users(name,email)VALUES('$name','$email')";
	$result = $connect->query_execute($query);

    if($result)
    {
       echo "Record Inserted Successfully";
    }
    else
    {
        echo "data not inserted";
    }
}

$users = $connect->query_execute("SELECT * FROM users");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Database With Interface</title>
    <style>
    	body{
    		background-color: lightcoral;
    	}
    	h1{
    		background-color: cyan;
    		border-radius: 10px 5px;
    	}
    	fieldset{
    		background-color: darkgoldenrod;
    	}
    	legend{
    		color: whitesmoke;
    		font-size: 30px;
    		font-family: cursive;
    	}
    </style>
</head>
<body>
<center>

	<h1>Database With Interface</h1>
	<fieldset style="width:400px;">
	    <legend>Insert User</legend>
	
	    <form method="POST">
	    	<table cellpadding="10px" cellspacing="10">
	    		<tr>
	    			<td>
	        			<input type="text"name="name"placeholder="Enter Name"required>
	    			</td>
	    		</tr>
				<tr>
					<td>
	        			<input type="email"name="email"placeholder="Enter Email"required>
					</td>
				</tr>
				<tr align="center">
	        		<td><input type="submit"name="submit"value="Submit"></td>
				</tr>
	
	    	</table>
		
	    </form>
	</fieldset>
	<h2>Users Record</h2>
	<table border="1" cellpadding="10" cellspacing="0">
		<tr>
		    <th>ID</th>
		    <th>Name</th>
		    <th>Email</th>
		</tr>
		<?php
		while($row = mysqli_fetch_assoc($users))
		{
		?>
			<tr>
			    <td><?php echo $row['user_id']; ?></td>
			    <td><?php echo $row['name']; ?></td>
			    <td><?php echo $row['email']; ?></td>
			</tr>
		<?php
		}
		?>
	</table>
</center>
</body>
</html>