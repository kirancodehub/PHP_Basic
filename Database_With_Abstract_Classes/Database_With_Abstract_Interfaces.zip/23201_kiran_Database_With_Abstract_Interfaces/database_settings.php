<?php

mysqli_report(MYSQLI_REPORT_OFF);

$hostname = "localhost";
$username = "root";
$password = "";
$database_name = "management_system";

?>